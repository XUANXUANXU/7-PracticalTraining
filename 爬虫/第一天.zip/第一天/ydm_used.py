from PythonHTTP.YDMHTTPHandler import get_code_result_by_filename
import requests

headers = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

#获取验证码：
url = "https://www.douban.com/misc/captcha?id=tuvjIlLfdVLHQZmnLubDsZ8C:en&size=s"

response = requests.get(url,headers=headers)

if response.status_code == 200:
    with open('image.png','wb') as file:
        file.write(response.content)

else:
    print('下载失败')

codetype = 3009
result = get_code_result_by_filename('image.png',codetype)

print(result)