<template>
	<div>
		<h2>Your Cart</h2>
		<ul>
			<li v-for="item in cartProduts">
				{{item.title}}--${{item.price}}x{{item.count}}
			</li>
		</ul>
		<p>Total: {{totalPrice}}</p>
	</div>
</template>

<script>
	import {mapGetters, mapActions} from 'vuex'

	export default{
		computed: {
			...mapGetters(['cartProduts']),
			totalPrice () {
				return this.cartProduts.reduce((prePrice, item) => {
					return prePrice + item.price * item.count
				}, 0)
			}
		}
	}
</script>

<style>
	
</style>