/*包含所有基于state的getter计算属性的对象*/
export default{
	cartProduts (state) {
		return state.items.map(({id, count}) => {
			var p = state.products.find(p => p.id === id)
			return {
				id,
				count,
				title: p.title,
				price: p.price
			}
		})
	}
}