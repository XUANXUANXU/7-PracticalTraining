/*包含多个由action触发，去直接更新状态的方法的对象*/
import {ADD_TO_CART} from './types'

export default{
	[ADD_TO_CART](state, {id}){
		state.products.find(p => p.id===id).inventory--
		const item = state.items.find(item => item.id===id)
		if(item){
			item.count++
		}else{
			state.items.unshift({
				id,
				count: 1
			})
		}
	}
}