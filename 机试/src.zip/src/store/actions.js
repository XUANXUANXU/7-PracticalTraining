/*包含多个接收组件的通知，触发mutation调用，间接更新状态的方法的对象*/
import {ADD_TO_CART} from './types'

export default {
	addToCart ({commit}, p) {
		if(p.inventory) {
			commit(ADD_TO_CART, {id: p.id})
		}
	}
}